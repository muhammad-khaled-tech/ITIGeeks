// OPTIMIZED: leaderboardService.js
// Progressive sync with priority user and atomic updates

import { db } from '../config/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { LeetCodeAPI } from './leetcodeAPI';

// ===== PROGRESSIVE SYNC ENGINE =====

/**
 * Fetch and sync group members with progressive updates
 * @param {string} groupId - The group to sync
 * @param {string} priorityUserId - User to fetch first (optional)
 * @param {Array} localProblems - Local problem tracking
 * @param {Function} onProgress - Callback for progress updates
 */
export async function fetchGroupMembers(
  groupId, 
  priorityUserId = null,
  localProblems = [],
  onProgress = null
) {
  console.log(`[LeaderboardSync] Starting for group: ${groupId}`);
  
  // 1. Fetch group members from Firestore
  const membersSnapshot = await db
    .collection('users')
    .where('groupId', '==', groupId)
    .where('role', '==', 'student')
    .get();

  const allMembers = membersSnapshot.docs.map(doc => ({
    uid: doc.id,
    ...doc.data()
  }));

  if (allMembers.length === 0) {
    console.warn('[LeaderboardSync] No members found');
    return [];
  }

  console.log(`[LeaderboardSync] Found ${allMembers.length} members`);

  // 2. Prioritize active user
  let orderedMembers = [...allMembers];
  if (priorityUserId) {
    const priorityIndex = orderedMembers.findIndex(m => m.uid === priorityUserId);
    if (priorityIndex > -1) {
      const [priorityUser] = orderedMembers.splice(priorityIndex, 1);
      orderedMembers = [priorityUser, ...orderedMembers];
      console.log(`[LeaderboardSync] ⭐ Priority user: ${priorityUser.displayName}`);
    }
  }

  // 3. Progressive sync with atomic updates
  const results = [];
  const cacheRef = doc(db, 'leaderboardCache', groupId);
  
  let completed = 0;
  let priorityUserDone = false;

  // Process all members concurrently (LeetCodeAPI.requestQueue handles throttling)
  const syncPromises = orderedMembers.map(async (member, index) => {
    const isPriority = index === 0 && priorityUserId;
    
    try {
      console.log(`[LeaderboardSync] Syncing ${member.displayName}...`);
      
      // Fetch LeetCode data (naturally throttled by LeetCodeAPI.requestQueue)
      const lcData = await LeetCodeAPI.getCombinedData(member.leetcodeUsername);
      
      // Get local problems for this user
      const userLocalProblems = localProblems.filter(
        p => p.userId === member.uid && p.status === 'done'
      );
      
      // Merge stats
      const mergedStats = mergeStats(lcData, userLocalProblems);
      
      // Calculate additional metrics
      const streak = calculateStreak(lcData.submissionCalendar);
      const points = calculatePoints(mergedStats);
      
      const userData = {
        uid: member.uid,
        displayName: member.displayName,
        email: member.email,
        avatar: member.avatar || lcData.avatar,
        leetcodeUsername: member.leetcodeUsername,
        ...mergedStats,
        streak,
        points,
        lastSynced: new Date().toISOString(),
        _syncedAt: Date.now()
      };

      results.push(userData);
      completed++;

      // ⚡ ATOMIC UPDATE: Save immediately after each user
      await updateLeaderboardAtomic(cacheRef, userData, groupId);

      console.log(
        `[LeaderboardSync] ✅ ${member.displayName}: ${mergedStats.totalSolved} problems`
      );

      // Mark priority user as done
      if (isPriority) {
        priorityUserDone = true;
        console.log('[LeaderboardSync] 🎯 Priority user synced!');
      }

      // Progress callback
      if (onProgress) {
        onProgress({
          completed,
          total: allMembers.length,
          current: member.displayName,
          priorityDone: priorityUserDone
        });
      }

      return userData;

    } catch (error) {
      console.error(`[LeaderboardSync] ❌ Failed for ${member.displayName}:`, error);
      
      // Return cached/default data
      return {
        uid: member.uid,
        displayName: member.displayName,
        email: member.email,
        avatar: member.avatar,
        totalSolved: 0,
        easySolved: 0,
        mediumSolved: 0,
        hardSolved: 0,
        streak: 0,
        points: 0,
        _error: error.message,
        lastSynced: new Date().toISOString()
      };
    }
  });

  // Wait for all to complete (in parallel, naturally throttled)
  await Promise.all(syncPromises);

  console.log(`[LeaderboardSync] ✅ All ${allMembers.length} members synced`);
  
  return results.sort((a, b) => b.points - a.points);
}

/**
 * Atomic update to Firestore - updates one user in the cache
 */
async function updateLeaderboardAtomic(cacheRef, userData, groupId) {
  try {
    await setDoc(cacheRef, {
      groupId,
      members: {
        [userData.uid]: userData
      },
      lastUpdated: serverTimestamp(),
      _partial: true // Flag to indicate progressive update
    }, { merge: true });
    
  } catch (error) {
    console.error('[LeaderboardSync] Failed atomic update:', error);
    // Don't throw - allow other updates to continue
  }
}

/**
 * Finalize leaderboard - calculate final rankings
 */
async function finalizeLeaderboard(groupId, allMembers) {
  const cacheRef = doc(db, 'leaderboardCache', groupId);
  
  // Sort by points
  const sorted = allMembers.sort((a, b) => b.points - a.points);
  
  // Assign ranks
  sorted.forEach((member, index) => {
    member.rank = index + 1;
  });

  // Convert to map
  const membersMap = {};
  sorted.forEach(member => {
    membersMap[member.uid] = member;
  });

  // Final atomic update with complete flag
  await setDoc(cacheRef, {
    groupId,
    members: membersMap,
    lastUpdated: serverTimestamp(),
    _partial: false, // Mark as complete
    _finalizedAt: Date.now()
  });

  console.log('[LeaderboardSync] 🏁 Finalized with rankings');
}

// ===== RESPONSIVE REFRESH =====

/**
 * Refresh leaderboard with priority user
 * Returns immediately after priority user is synced
 */
export async function refreshLeaderboard(groupId, priorityUserId = null) {
  console.log(`[RefreshLeaderboard] Starting for group: ${groupId}`);
  
  let priorityResolved = false;
  const results = [];

  try {
    // Start progressive sync
    const syncPromise = fetchGroupMembers(
      groupId,
      priorityUserId,
      [], // Local problems (fetch if needed)
      (progress) => {
        // Callback for progress
        if (progress.priorityDone && !priorityResolved) {
          priorityResolved = true;
          console.log('[RefreshLeaderboard] Priority user ready!');
        }
      }
    );

    // If priority user specified, wait only for them
    if (priorityUserId) {
      // Poll until priority user is synced
      const priorityTimeout = 30000; // 30 seconds max
      const startTime = Date.now();
      
      while (!priorityResolved && (Date.now() - startTime) < priorityTimeout) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      if (priorityResolved) {
        console.log('[RefreshLeaderboard] ✅ Priority user synced, continuing in background');
        
        // Continue syncing rest in background
        syncPromise.then(allResults => {
          finalizeLeaderboard(groupId, allResults);
        }).catch(err => {
          console.error('[RefreshLeaderboard] Background sync error:', err);
        });

        return { success: true, priorityReady: true };
      }
    }

    // If no priority or timeout, wait for all
    const allResults = await syncPromise;
    await finalizeLeaderboard(groupId, allResults);

    return { success: true, results: allResults };

  } catch (error) {
    console.error('[RefreshLeaderboard] Error:', error);
    return { success: false, error: error.message };
  }
}

// ===== HELPER FUNCTIONS =====

export function mergeStats(lcStats, localProblems = []) {
  const apiTotal = lcStats?.totalSolved || 0;
  const apiEasy = lcStats?.easySolved || 0;
  const apiMedium = lcStats?.mediumSolved || 0;
  const apiHard = lcStats?.hardSolved || 0;

  const localDone = localProblems.filter(p => p.status === 'done');
  const localEasy = localDone.filter(p => p.difficulty === 'Easy').length;
  const localMedium = localDone.filter(p => p.difficulty === 'Medium').length;
  const localHard = localDone.filter(p => p.difficulty === 'Hard').length;

  return {
    totalSolved: Math.max(apiTotal, localEasy + localMedium + localHard),
    easySolved: Math.max(apiEasy, localEasy),
    mediumSolved: Math.max(apiMedium, localMedium),
    hardSolved: Math.max(apiHard, localHard)
  };
}

export function calculateStreak(calendar) {
  if (!calendar) return 0;
  
  let streak = 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  for (let i = 0; i < 365; i++) {
    const checkDate = new Date(today);
    checkDate.setDate(checkDate.getDate() - i);
    const timestamp = Math.floor(checkDate.getTime() / 1000);
    
    if (calendar[timestamp] && calendar[timestamp] > 0) {
      streak++;
    } else if (i > 0) {
      break;
    }
  }
  
  return streak;
}

export function calculatePoints(stats) {
  return (stats.easySolved * 1) + (stats.mediumSolved * 2) + (stats.hardSolved * 3);
}
