// OPTIMIZED: GroupLeaderboard.jsx
// Progressive UI updates with real-time member status

import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../config/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { refreshLeaderboard } from '../../services/leaderboardService';

function GroupLeaderboard() {
  const { currentUser } = useAuth();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [syncStatus, setSyncStatus] = useState({}); // Track individual member status
  const [priorityReady, setPriorityReady] = useState(false);

  const groupId = currentUser?.groupId;

  // ===== REAL-TIME LISTENER =====
  useEffect(() => {
    if (!groupId) return;

    console.log('[GroupLeaderboard] Setting up real-time listener');

    const cacheRef = doc(db, 'leaderboardCache', groupId);
    
    const unsubscribe = onSnapshot(cacheRef, (snapshot) => {
      if (!snapshot.exists()) {
        setLoading(false);
        return;
      }

      const data = snapshot.data();
      const membersMap = data.members || {};
      const isPartial = data._partial;

      // Convert map to array
      const membersArray = Object.values(membersMap);
      
      // Sort by points
      const sorted = membersArray.sort((a, b) => {
        const pointsA = b.points || 0;
        const pointsB = a.points || 0;
        return pointsB - pointsA;
      });

      // Assign ranks
      sorted.forEach((member, index) => {
        member.rank = index + 1;
      });

      console.log(
        `[GroupLeaderboard] 📊 Updated: ${sorted.length} members ` +
        `(partial: ${isPartial})`
      );

      setMembers(sorted);
      setLoading(false);

      // Update sync status
      const newStatus = {};
      sorted.forEach(member => {
        const age = Date.now() - (member._syncedAt || 0);
        newStatus[member.uid] = {
          syncing: age < 5000, // Recently synced (< 5s)
          upToDate: age < 300000, // Fresh (< 5 mins)
          lastSync: member.lastSynced
        };
      });
      setSyncStatus(newStatus);

      // Check if priority user (current user) is ready
      if (currentUser && membersMap[currentUser.uid]) {
        const myData = membersMap[currentUser.uid];
        if (myData._syncedAt && Date.now() - myData._syncedAt < 5000) {
          setPriorityReady(true);
          setRefreshing(false); // Stop spinner once my data is ready
        }
      }
    }, (error) => {
      console.error('[GroupLeaderboard] Listener error:', error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [groupId, currentUser]);

  // ===== REFRESH HANDLER =====
  const handleRefresh = async () => {
    if (refreshing) return;

    console.log('[GroupLeaderboard] 🔄 Refresh triggered by', currentUser.displayName);
    
    setRefreshing(true);
    setPriorityReady(false);

    try {
      // Trigger progressive refresh with priority
      const result = await refreshLeaderboard(groupId, currentUser.uid);

      if (result.priorityReady) {
        console.log('[GroupLeaderboard] ✅ My stats updated!');
        setPriorityReady(true);
        setRefreshing(false);
        
        // Show success notification
        showNotification('Your stats updated! Others syncing in background...', 'success');
      } else {
        // All complete
        setRefreshing(false);
        showNotification('Leaderboard fully refreshed!', 'success');
      }

    } catch (error) {
      console.error('[GroupLeaderboard] Refresh error:', error);
      setRefreshing(false);
      showNotification('Failed to refresh. Please try again.', 'error');
    }
  };

  // ===== UI HELPERS =====
  const showNotification = (message, type) => {
    // Your notification system
    console.log(`[Notification] ${type}: ${message}`);
  };

  const getMemberStatus = (member) => {
    const status = syncStatus[member.uid] || {};
    
    if (status.syncing) {
      return { icon: '🔄', label: 'Syncing...', color: 'text-blue-500' };
    }
    if (status.upToDate) {
      return { icon: '✅', label: 'Up to date', color: 'text-green-500' };
    }
    return { icon: '⏱️', label: 'Stale', color: 'text-gray-400' };
  };

  const isMyRow = (member) => member.uid === currentUser?.uid;

  // ===== RENDER =====
  if (loading) {
    return (
      <div className="loading-container">
        <Spinner />
        <p>Loading leaderboard...</p>
      </div>
    );
  }

  return (
    <div className="leaderboard-container">
      {/* Header */}
      <div className="leaderboard-header">
        <h1>📊 Group Leaderboard</h1>
        
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className={`refresh-btn ${refreshing ? 'refreshing' : ''}`}
        >
          {refreshing ? (
            <>
              <Spinner size="small" />
              {priorityReady ? 'Syncing others...' : 'Refreshing...'}
            </>
          ) : (
            <>🔄 Refresh Stats</>
          )}
        </button>
      </div>

      {/* Stats Summary */}
      {priorityReady && refreshing && (
        <div className="priority-notice">
          ✅ Your stats are updated! Others are syncing in the background.
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="leaderboard-table">
        <table>
          <thead>
            <tr>
              <th>Rank</th>
              <th>Student</th>
              <th>Total Solved</th>
              <th>Easy</th>
              <th>Medium</th>
              <th>Hard</th>
              <th>Streak</th>
              <th>Points</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {members.map((member) => {
              const status = getMemberStatus(member);
              const isMe = isMyRow(member);
              
              return (
                <tr
                  key={member.uid}
                  className={`
                    ${isMe ? 'my-row highlight' : ''}
                    ${status.syncing ? 'syncing' : ''}
                  `}
                >
                  <td className="rank-cell">
                    <span className={`rank rank-${member.rank}`}>
                      {member.rank === 1 ? '🥇' :
                       member.rank === 2 ? '🥈' :
                       member.rank === 3 ? '🥉' :
                       `#${member.rank}`}
                    </span>
                  </td>

                  <td className="student-cell">
                    <div className="student-info">
                      <img
                        src={member.avatar || '/default-avatar.png'}
                        alt={member.displayName}
                        className="avatar"
                      />
                      <div>
                        <div className="name">
                          {member.displayName}
                          {isMe && <span className="you-badge">You</span>}
                        </div>
                        <div className="username">
                          @{member.leetcodeUsername}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="total-cell">
                    <strong>{member.totalSolved || 0}</strong>
                  </td>

                  <td className="easy-cell">
                    {member.easySolved || 0}
                  </td>

                  <td className="medium-cell">
                    {member.mediumSolved || 0}
                  </td>

                  <td className="hard-cell">
                    {member.hardSolved || 0}
                  </td>

                  <td className="streak-cell">
                    {member.streak > 0 ? (
                      <span className="streak-badge">
                        🔥 {member.streak}
                      </span>
                    ) : (
                      <span className="no-streak">-</span>
                    )}
                  </td>

                  <td className="points-cell">
                    <strong>{member.points || 0}</strong>
                  </td>

                  <td className="status-cell">
                    <span className={`status-badge ${status.color}`}>
                      {status.icon} {status.label}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Empty State */}
      {members.length === 0 && (
        <div className="empty-state">
          <p>No members found in your group</p>
          <button onClick={handleRefresh}>Refresh</button>
        </div>
      )}
    </div>
  );
}

// ===== SPINNER COMPONENT =====
function Spinner({ size = 'medium' }) {
  return (
    <div className={`spinner spinner-${size}`}>
      <div className="spinner-circle" />
    </div>
  );
}

export default GroupLeaderboard;
