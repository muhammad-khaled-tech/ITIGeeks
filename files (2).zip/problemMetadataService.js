// /services/problemMetadataService.js
// Enriches LeetCode submissions with difficulty metadata

import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';

// In-memory cache (survives for session duration)
const memoryCache = new Map();

/**
 * Fetch problem difficulty from cache or LeetCode GraphQL API
 * @param {string} titleSlug - LeetCode problem slug (e.g., "two-sum")
 * @returns {Promise<string>} "Easy" | "Medium" | "Hard" | "Unknown"
 */
export async function getProblemDifficulty(titleSlug) {
  if (!titleSlug) return 'Unknown';
  
  // 1. Memory cache (instant)
  if (memoryCache.has(titleSlug)) {
    return memoryCache.get(titleSlug);
  }
  
  // 2. Firestore cache (fast)
  try {
    const docRef = doc(db, 'problemMetadata', titleSlug);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const difficulty = docSnap.data().difficulty;
      memoryCache.set(titleSlug, difficulty);
      return difficulty;
    }
  } catch (e) {
    console.warn(`[Metadata] Firestore lookup failed for ${titleSlug}:`, e.message);
  }
  
  // 3. Fetch from LeetCode GraphQL (slow but accurate)
  try {
    const response = await fetch('https://leetcode.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `
          query getProblemDifficulty($titleSlug: String!) {
            question(titleSlug: $titleSlug) {
              difficulty
            }
          }
        `,
        variables: { titleSlug }
      }),
      signal: AbortSignal.timeout(10000) // 10s timeout
    });
    
    if (!response.ok) {
      throw new Error(`GraphQL API returned ${response.status}`);
    }
    
    const data = await response.json();
    const difficulty = data?.data?.question?.difficulty || 'Unknown';
    
    // Cache in both memory and Firestore
    memoryCache.set(titleSlug, difficulty);
    
    try {
      await setDoc(doc(db, 'problemMetadata', titleSlug), {
        difficulty,
        titleSlug,
        updatedAt: new Date(),
        source: 'leetcode-graphql'
      });
    } catch (e) {
      console.warn(`[Metadata] Failed to cache ${titleSlug} in Firestore:`, e.message);
    }
    
    console.log(`[Metadata] ✅ Fetched ${titleSlug}: ${difficulty}`);
    return difficulty;
    
  } catch (error) {
    console.error(`[Metadata] ❌ Failed to fetch ${titleSlug}:`, error.message);
    // Fallback: Try to guess from common patterns (not reliable)
    return 'Medium'; // Safe default
  }
}

/**
 * Enrich an array of submissions with difficulty metadata
 * @param {Array} submissions - Array of submission objects with titleSlug
 * @returns {Promise<Array>} Enriched submissions with difficulty field
 */
export async function enrichSubmissions(submissions) {
  if (!Array.isArray(submissions) || submissions.length === 0) {
    return submissions;
  }
  
  // Batch fetch to avoid waterfall
  const enrichPromises = submissions.map(async (sub) => {
    if (!sub.titleSlug) {
      return { ...sub, difficulty: 'Unknown' };
    }
    
    const difficulty = await getProblemDifficulty(sub.titleSlug);
    return { ...sub, difficulty };
  });
  
  return Promise.all(enrichPromises);
}

/**
 * Batch pre-warm cache for a list of problem slugs
 * Useful for contest problems or curriculum problems
 * @param {Array<string>} slugs - Array of titleSlugs to pre-cache
 */
export async function prewarmCache(slugs) {
  console.log(`[Metadata] Pre-warming cache for ${slugs.length} problems...`);
  
  const results = await Promise.allSettled(
    slugs.map(slug => getProblemDifficulty(slug))
  );
  
  const success = results.filter(r => r.status === 'fulfilled').length;
  console.log(`[Metadata] Pre-warmed ${success}/${slugs.length} problems`);
  
  return success;
}

/**
 * Clear memory cache (useful for testing or memory management)
 */
export function clearCache() {
  memoryCache.clear();
  console.log('[Metadata] Memory cache cleared');
}

/**
 * Get cache statistics
 */
export function getCacheStats() {
  return {
    memoryCacheSize: memoryCache.size,
    cachedSlugs: Array.from(memoryCache.keys())
  };
}
