# IMPLEMENTATION GUIDE: Fix Monthly/Weekly "All Easy" Bug

## QUICK START (5 Minutes)

### Step 1: Add Problem Metadata Service

Create new file: `/src/services/problemMetadataService.js`

```bash
# Copy the file I created
cp /home/claude/problemMetadataService.js /your/project/src/services/
```

### Step 2: Modify leaderboardService.js

Add import at top of file (line ~16):

```javascript
import { enrichSubmissions } from './problemMetadataService';
```

### Step 3: Fix fetchUserStats() Function

Find line ~152 in leaderboardService.js and replace:

**OLD (Broken):**
```javascript
const recentSubmissions = rawSubmissions.map((s) => {
  let difficulty = s.difficulty;
  if (!difficulty && s.titleSlug) difficulty = "Unknown";
  
  return {
    timestamp: parseInt(s.timestamp),
    difficulty: difficulty,
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  };
});
```

**NEW (Fixed):**
```javascript
// Enrich submissions with difficulty metadata
const recentSubmissions = await enrichSubmissions(
  rawSubmissions.map((s) => ({
    timestamp: parseInt(s.timestamp),
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  }))
);
```

### Step 4: Fix processLeaderboard() Function

Find line ~911 and replace entire function:

```bash
# Use the patch file
# See leaderboardService_PATCH.js for complete replacement code
```

Key changes:
- Actually use `timePeriod` parameter
- Filter submissions by date
- Recalculate Easy/Medium/Hard counts from filtered submissions
- Recalculate points for time period

### Step 5: Test

```bash
npm start
```

Navigate to Group Leaderboard:
1. Switch to "Monthly" tab
2. Verify Easy/Medium/Hard counts are correct (not all Easy)
3. Switch to "Weekly" tab
4. Verify counts update correctly

---

## DETAILED IMPLEMENTATION

### File 1: problemMetadataService.js (NEW)

**Location:** `/src/services/problemMetadataService.js`

**Purpose:**
- Fetch problem difficulty from LeetCode GraphQL
- Cache in Firestore (permanent)
- Cache in memory (session)
- Enrich submission arrays

**Key Functions:**
```javascript
getProblemDifficulty(titleSlug)    // Get difficulty for one problem
enrichSubmissions(submissions)      // Enrich array of submissions
prewarmCache(slugs)                // Pre-cache contest problems
```

**Dependencies:**
- `firebase/firestore` (already installed)
- Fetch API (built-in)

---

### File 2: leaderboardService.js (MODIFIED)

#### Change A: Import Statement

**Line:** ~16
```javascript
import { enrichSubmissions } from './problemMetadataService';
```

#### Change B: fetchUserStats() - Line ~152

**Before:**
```javascript
const rawSubmissions = data.recentSubmissions || data.submission || [];
const recentSubmissions = rawSubmissions.map((s) => {
  let difficulty = s.difficulty;
  if (!difficulty && s.titleSlug) difficulty = "Unknown";
  return {
    timestamp: parseInt(s.timestamp),
    difficulty: difficulty,
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  };
});
```

**After:**
```javascript
const rawSubmissions = data.recentSubmissions || data.submission || [];

// ✅ FIX: Enrich with difficulty metadata
const recentSubmissions = await enrichSubmissions(
  rawSubmissions.map((s) => ({
    timestamp: parseInt(s.timestamp),
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  }))
);
```

**Impact:**
- Submissions now have correct difficulty field
- First time: slower (fetch from GraphQL)
- Cached: instant

#### Change C: processLeaderboard() - Line ~911

Replace entire function with version from `leaderboardService_PATCH.js`.

**Key additions:**
1. Time period filtering logic
2. Difficulty-based counting
3. Points recalculation
4. Helper function `getCutoffTimestamp()`

**Before:**
```javascript
export function processLeaderboard(members, timePeriod, mode = "overall") {
  let processed = [...members];
  
  if (mode === "overall") {
    processed.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));
  } else {
    processed.sort((a, b) => (b.contestPoints || 0) - (a.contestPoints || 0));
  }
  
  processed = processed.map((member, index) => ({
    ...member,
    rank: index + 1,
  }));
  
  return processed;
}
```

**After:** See full replacement in patch file.

---

## FIRESTORE SCHEMA CHANGES

### New Collection: `problemMetadata`

```
/problemMetadata/{titleSlug}
  - difficulty: "Easy" | "Medium" | "Hard"
  - titleSlug: string
  - updatedAt: Timestamp
  - source: "leetcode-graphql"
```

**Example Documents:**
```
/problemMetadata/two-sum
  difficulty: "Easy"
  titleSlug: "two-sum"
  updatedAt: 2025-01-30T10:30:00Z

/problemMetadata/median-of-two-sorted-arrays
  difficulty: "Hard"
  titleSlug: "median-of-two-sorted-arrays"
  updatedAt: 2025-01-30T10:31:00Z
```

**Indexes:** None needed (simple document lookups)

**Security Rules:**
```javascript
match /problemMetadata/{slug} {
  allow read: if true;  // Public read
  allow write: if false; // Only backend writes
}
```

---

## TESTING CHECKLIST

### Unit Tests

```javascript
// Test difficulty enrichment
test('enrichSubmissions adds difficulty', async () => {
  const subs = [{ titleSlug: 'two-sum', timestamp: 123 }];
  const enriched = await enrichSubmissions(subs);
  expect(enriched[0].difficulty).toBe('Easy');
});

// Test time filtering
test('processLeaderboard filters by month', () => {
  const members = [{
    recentSubmissions: [
      { difficulty: 'Easy', timestamp: Date.now() - 10 * 24*60*60*1000 }, // 10 days ago
      { difficulty: 'Medium', timestamp: Date.now() - 60 * 24*60*60*1000 } // 60 days ago
    ]
  }];
  
  const result = processLeaderboard(members, 'month');
  expect(result[0].easySolved).toBe(1); // Only recent submission counted
});
```

### Manual Testing

**Test Case 1: Monthly View**
1. Open Group Leaderboard
2. Click "Monthly" tab
3. Find a user who solved problems this month
4. Verify: Easy/Medium/Hard counts match their actual submissions
5. Expected: NOT all showing as Easy

**Test Case 2: Weekly View**
1. Click "Weekly" tab
2. Find a user with no activity this week
3. Verify: Shows 0/0/0 (not their overall stats)

**Test Case 3: Overall View**
1. Click "Overall" tab
2. Verify: Shows lifetime totals (unchanged behavior)

**Test Case 4: Cache Performance**
1. First load: Should be slower (fetching metadata)
2. Refresh page
3. Second load: Should be instant (cached)

**Test Case 5: Firestore Data**
1. Open Firebase Console
2. Check `problemMetadata` collection exists
3. Verify documents have correct structure
4. Check a few known problems (two-sum, reverse-linked-list)

---

## ROLLBACK PLAN

If something goes wrong:

### Quick Rollback (5 minutes)

1. Revert leaderboardService.js:
```bash
git checkout leaderboardService.js
```

2. Remove import:
```bash
# Delete line: import { enrichSubmissions } from './problemMetadataService';
```

3. Delete problemMetadataService.js:
```bash
rm src/services/problemMetadataService.js
```

### Keep Data

The `problemMetadata` collection is harmless and can be kept for future use.

---

## MONITORING

### Console Logs to Watch

**Success Indicators:**
```
[Metadata] ✅ Fetched two-sum: Easy
[Metadata] Pre-warmed 150/150 problems
[LeaderboardSync] 🏁 Finalized with rankings
```

**Warning Signs:**
```
[Metadata] ❌ Failed to fetch problem-xyz: 404
[Metadata] Firestore lookup failed: permission-denied
```

### Performance Metrics

**Initial sync (cold cache):**
- Expected: 30-60 seconds for 50 users
- Acceptable: < 2 minutes

**Subsequent loads:**
- Expected: < 2 seconds
- Acceptable: < 5 seconds

**Cache hit rate:**
- After 1 hour: Should be > 95%
- After 24 hours: Should be > 99%

---

## OPTIONAL ENHANCEMENTS

### Enhancement 1: Pre-warm Cache for Contests

When creating a contest, pre-cache all problem difficulties:

```javascript
// In ContestManager.jsx after contest creation
import { prewarmCache } from '../services/problemMetadataService';

await addDoc(collection(db, 'contests'), contestData);
const slugs = problems.map(p => p.slug);
await prewarmCache(slugs); // Pre-fetch all problems
```

### Enhancement 2: Batch GraphQL Queries

Modify problemMetadataService.js to fetch multiple problems in one GraphQL call:

```javascript
async function batchGetDifficulties(slugs) {
  const query = `
    query {
      ${slugs.map((s, i) => `
        q${i}: question(titleSlug: "${s}") { difficulty }
      `).join('\n')}
    }
  `;
  // Parse response and update cache
}
```

### Enhancement 3: Admin Dashboard

Show cache statistics:

```javascript
import { getCacheStats } from '../services/problemMetadataService';

console.log(getCacheStats());
// { memoryCacheSize: 847, cachedSlugs: [...] }
```

---

## COST ANALYSIS

### Free Tier Limits

**Firestore:**
- Reads: 50K/day (we use ~1K/day after warmup)
- Writes: 20K/day (we use ~1K one-time)
- Storage: 1GB (problemMetadata ~1MB)

**LeetCode GraphQL:**
- No official rate limit
- Typical: ~1000 problems cached one-time
- Subsequent: 0 calls (100% cache)

**Verdict:** Well within free tier ✅

### Paid Tier Scaling

At 1000 users:
- ~5000 unique problems
- 5000 GraphQL calls (one-time)
- ~500KB Firestore storage
- Still free ✅

---

## FAQ

**Q: What if LeetCode changes problem difficulty?**
A: Very rare, but metadata has `updatedAt` field. Could add TTL refresh logic.

**Q: What about premium problems?**
A: GraphQL returns null → default to "Medium" → works fine.

**Q: Performance on mobile?**
A: Memory cache is small (~100KB). No impact.

**Q: What if GraphQL API is down?**
A: Falls back to "Medium" default. Non-critical failure.

**Q: Can we use AlFA-LeetCode-API instead?**
A: No, it also doesn't include difficulty in submissions endpoint.

---

## SUPPORT

If issues arise:

1. Check console for error logs
2. Verify Firebase permissions
3. Check Network tab for GraphQL failures
4. Test with a single user first
5. Compare Overall vs Monthly stats manually

Contact: [Your team channel]
