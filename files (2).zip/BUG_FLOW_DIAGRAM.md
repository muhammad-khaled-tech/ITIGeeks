# VISUAL BUG ANALYSIS: Monthly/Weekly "All Easy" Problem

## CURRENT (BROKEN) FLOW

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. LeetCode API Returns Submissions                            │
│                                                                 │
│ {                                                               │
│   recentSubmissions: [                                          │
│     {                                                           │
│       titleSlug: "two-sum",                                    │
│       timestamp: "1705516800",                                 │
│       status: "Accepted",                                       │
│       difficulty: undefined  // ❌ NOT PROVIDED BY API         │
│     },                                                          │
│     { titleSlug: "add-two-numbers", ... }                      │
│   ]                                                             │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 2. fetchUserStats() Maps Submissions (line 154-164)            │
│                                                                 │
│ const recentSubmissions = rawSubmissions.map(s => ({           │
│   timestamp: parseInt(s.timestamp),                            │
│   difficulty: s.difficulty || "Unknown",  // ❌ All "Unknown" │
│   status: s.statusDisplay,                                     │
│   titleSlug: s.titleSlug                                       │
│ }));                                                            │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 3. Stored in Firestore Cache                                   │
│                                                                 │
│ members: {                                                      │
│   "user123": {                                                  │
│     totalSolved: 150,                                           │
│     easySolved: 80,    // ✅ Overall stats are correct        │
│     mediumSolved: 60,                                           │
│     hardSolved: 10,                                             │
│     recentSubmissions: [                                        │
│       { difficulty: "Unknown", ... },  // ❌ Problem!          │
│       { difficulty: "Unknown", ... }                            │
│     ]                                                           │
│   }                                                             │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 4. processLeaderboard() Called with timePeriod="month"         │
│                                                                 │
│ export function processLeaderboard(members, timePeriod) {      │
│   // ❌ BUG: timePeriod parameter COMPLETELY IGNORED           │
│   return members.sort(...).map(m => ({ ...m, rank: i+1 }));   │
│ }                                                               │
│                                                                 │
│ // Returns members with OVERALL stats, not monthly stats       │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 5. EnhancedLeaderboard Component Tries to Filter               │
│                                                                 │
│ const monthlySubmissions = member.recentSubmissions             │
│   .filter(s => s.timestamp > lastMonth);                       │
│                                                                 │
│ const easy = monthlySubmissions                                 │
│   .filter(s => s.difficulty === "Easy").length;  // 0         │
│ const medium = monthlySubmissions                               │
│   .filter(s => s.difficulty === "Medium").length; // 0         │
│ const hard = monthlySubmissions                                 │
│   .filter(s => s.difficulty === "Hard").length;   // 0         │
│                                                                 │
│ // ❌ All are "Unknown", so counts are 0                        │
│ // UI defaults to showing all as "Easy"                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## FIXED FLOW

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. LeetCode API Returns Submissions (same as before)           │
│                                                                 │
│ { recentSubmissions: [{ titleSlug: "two-sum", ... }] }        │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 2. NEW: Enrich Submissions with Difficulty Metadata            │
│                                                                 │
│ import { enrichSubmissions } from './problemMetadataService';  │
│                                                                 │
│ const enriched = await enrichSubmissions(rawSubmissions);      │
│                                                                 │
│ // For each submission:                                         │
│ //   1. Check memory cache (instant)                           │
│ //   2. Check Firestore cache (fast)                           │
│ //   3. Fetch from LeetCode GraphQL (slow, one-time)           │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 3. LeetCode GraphQL API Called (for new problems only)         │
│                                                                 │
│ POST https://leetcode.com/graphql                              │
│ {                                                               │
│   query: "query { question(titleSlug: $slug) { difficulty }}" │
│ }                                                               │
│                                                                 │
│ Response: { data: { question: { difficulty: "Easy" }}}        │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 4. Cache Difficulty in Firestore (permanent)                   │
│                                                                 │
│ /problemMetadata/two-sum                                        │
│   - difficulty: "Easy"                                          │
│   - titleSlug: "two-sum"                                        │
│   - updatedAt: Timestamp                                        │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 5. Stored in Firestore Cache (with correct difficulty)         │
│                                                                 │
│ members: {                                                      │
│   "user123": {                                                  │
│     recentSubmissions: [                                        │
│       {                                                         │
│         titleSlug: "two-sum",                                  │
│         difficulty: "Easy",  // ✅ CORRECT                     │
│         timestamp: 1705516800                                   │
│       },                                                        │
│       {                                                         │
│         titleSlug: "reverse-linked-list",                      │
│         difficulty: "Medium", // ✅ CORRECT                    │
│         timestamp: 1705430400                                   │
│       }                                                         │
│     ]                                                           │
│   }                                                             │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 6. FIXED: processLeaderboard() Filters by Time Period          │
│                                                                 │
│ export function processLeaderboard(members, timePeriod) {      │
│   if (timePeriod !== 'all') {                                  │
│     const cutoff = getCutoffTimestamp(timePeriod);             │
│                                                                 │
│     members = members.map(m => {                                │
│       // Filter submissions in time range                       │
│       const filtered = m.recentSubmissions                      │
│         .filter(s => s.timestamp >= cutoff);                   │
│                                                                 │
│       // Count by difficulty                                    │
│       const easy = filtered                                     │
│         .filter(s => s.difficulty === "Easy").length;          │
│       const medium = filtered                                   │
│         .filter(s => s.difficulty === "Medium").length;        │
│       const hard = filtered                                     │
│         .filter(s => s.difficulty === "Hard").length;          │
│                                                                 │
│       return { ...m, easySolved: easy, mediumSolved: medium,   │
│                hardSolved: hard, totalSolved: easy+medium+hard }│
│     });                                                         │
│   }                                                             │
│   return members.sort(...);                                     │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ 7. EnhancedLeaderboard Displays Correct Stats                  │
│                                                                 │
│ Monthly View:                                                   │
│   User A: 3 Easy, 5 Medium, 2 Hard (this month)               │
│   User B: 10 Easy, 0 Medium, 0 Hard (this month)              │
│                                                                 │
│ Weekly View:                                                    │
│   User A: 1 Easy, 2 Medium, 0 Hard (this week)                │
│   User B: 0 Easy, 0 Medium, 0 Hard (this week)                │
│                                                                 │
│ ✅ All difficulty counts are ACCURATE                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## KEY INSIGHTS

### Why Overall Leaderboard Works:
- Uses `easySolved`, `mediumSolved`, `hardSolved` from LeetCode API
- These totals are provided directly (lifetime stats)
- No need to parse individual submissions

### Why Monthly/Weekly Don't Work:
- Need to filter submissions by date range
- Submissions from LeetCode API lack `difficulty` field
- Without difficulty, can't count Easy/Medium/Hard for time period

### The Fix:
- Enrich submissions with difficulty from LeetCode GraphQL
- Cache difficulty permanently (problem difficulty never changes)
- Filter and count correctly in processLeaderboard()

---

## PERFORMANCE IMPACT

**Initial Load (Cold Cache):**
- 50 users × 500 submissions = 25,000 submissions
- ~1,000 unique problems
- 1,000 GraphQL calls (batched, ~30s total)
- One-time cost

**Subsequent Loads:**
- 0 GraphQL calls (100% cache hits)
- < 1s to process leaderboard

**Memory:**
- ~1,000 problems × 100 bytes = 100 KB (negligible)

**Firestore:**
- 1,000 documents in problemMetadata collection
- 1 read per unique problem (cached client-side too)
