// PATCH FILE: Changes needed in leaderboardService.js
// Apply these modifications to fix monthly/weekly "All Easy" bug

// ==================== SECTION 1: ADD IMPORT ====================
// Add at top of file (around line 15):

import { enrichSubmissions } from './problemMetadataService';

// ==================== SECTION 2: FIX fetchUserStats() ====================
// Replace lines 152-164 with:

// 4. Map submissions with ENRICHED difficulty metadata
const rawSubmissions = data.recentSubmissions || data.submission || [];
const recentSubmissions = await enrichSubmissions(
  rawSubmissions.map((s) => ({
    timestamp: parseInt(s.timestamp),
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  }))
);

// Note: enrichSubmissions is async, so this function must be async (already is)

// ==================== SECTION 3: FIX processLeaderboard() ====================
// Replace entire function (lines 911-929) with:

export function processLeaderboard(members, timePeriod, mode = "overall") {
  let processed = [...members];
  
  // Apply time-based filtering for monthly/weekly views
  if (timePeriod !== 'all') {
    const cutoffTimestamp = getCutoffTimestamp(timePeriod);
    
    processed = processed.map(member => {
      // Filter submissions within time period
      const filteredSubmissions = (member.recentSubmissions || [])
        .filter(s => {
          const subTimestamp = parseInt(s.timestamp);
          // Handle both seconds and milliseconds timestamps
          const normalizedTimestamp = subTimestamp < 10000000000 
            ? subTimestamp * 1000 
            : subTimestamp;
          return normalizedTimestamp >= cutoffTimestamp;
        })
        .filter(s => s.status === 'Accepted' || s.status === 'Accepted'); // Only accepted
      
      // Count by difficulty
      const easy = filteredSubmissions.filter(s => s.difficulty === 'Easy').length;
      const medium = filteredSubmissions.filter(s => s.difficulty === 'Medium').length;
      const hard = filteredSubmissions.filter(s => s.difficulty === 'Hard').length;
      const total = easy + medium + hard;
      
      // Recalculate points for this time period
      const easyPoints = easy * POINTS.EASY;
      const mediumPoints = medium * POINTS.MEDIUM;
      const hardPoints = hard * POINTS.HARD;
      
      // Calculate streak for time period (using calendar data)
      let periodStreak = 0;
      if (member.submissionCalendar) {
        const calendar = typeof member.submissionCalendar === 'string' 
          ? JSON.parse(member.submissionCalendar) 
          : member.submissionCalendar;
        
        // Count unique days in time period
        const activeDaysInPeriod = Object.keys(calendar)
          .map(ts => parseInt(ts) * 1000)
          .filter(ts => ts >= cutoffTimestamp)
          .map(ts => Math.floor(ts / (24 * 60 * 60 * 1000))) // Convert to day number
          .filter((day, i, arr) => arr.indexOf(day) === i) // Unique days
          .length;
        
        periodStreak = activeDaysInPeriod;
      }
      
      const streakPoints = periodStreak * POINTS.STREAK_BONUS;
      const totalPoints = easyPoints + mediumPoints + hardPoints + streakPoints;
      
      return {
        ...member,
        // Override with period-specific stats
        easySolved: easy,
        mediumSolved: medium,
        hardSolved: hard,
        totalSolved: total,
        currentStreak: periodStreak,
        totalPoints: totalPoints,
        // Keep original stats for reference
        _originalEasy: member.easySolved,
        _originalMedium: member.mediumSolved,
        _originalHard: member.hardSolved,
        _originalTotal: member.totalSolved,
        _timePeriod: timePeriod
      };
    });
  }
  
  // Sort by appropriate metric
  if (mode === "overall") {
    processed.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));
  } else {
    processed.sort((a, b) => (b.contestPoints || 0) - (a.contestPoints || 0));
  }
  
  // Add rank
  processed = processed.map((member, index) => ({
    ...member,
    rank: index + 1,
  }));
  
  return processed;
}

// ==================== SECTION 4: ADD HELPER FUNCTION ====================
// Add this new helper function after processLeaderboard():

/**
 * Get cutoff timestamp for time period filtering
 * @param {string} timePeriod - 'week' | 'month' | 'all'
 * @returns {number} Unix timestamp in milliseconds
 */
function getCutoffTimestamp(timePeriod) {
  const now = Date.now();
  
  if (timePeriod === 'week') {
    return now - (7 * 24 * 60 * 60 * 1000);
  }
  
  if (timePeriod === 'month') {
    return now - (30 * 24 * 60 * 60 * 1000);
  }
  
  // 'all' or unknown
  return 0;
}

// ==================== VERIFICATION STEPS ====================
/*
After applying this patch:

1. Check console for enrichment logs:
   - Should see "[Metadata] ✅ Fetched two-sum: Easy"

2. Inspect member objects in processLeaderboard:
   - member.recentSubmissions[0].difficulty should be "Easy"/"Medium"/"Hard"

3. Test monthly view:
   - User who solved 10 problems this month should show correct breakdown
   - User who solved 0 problems this month should show 0/0/0

4. Verify Firestore:
   - New collection 'problemMetadata' should appear
   - Documents should have { difficulty, titleSlug, updatedAt }

5. Performance check:
   - First load: slower (fetching metadata)
   - Subsequent loads: fast (cached)
   - After 1 hour: near-instant (all metadata cached)
*/
