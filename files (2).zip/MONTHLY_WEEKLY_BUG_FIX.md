# CRITICAL BUG: Monthly/Weekly Leaderboards Show All Problems as "Easy"

## ROOT CAUSE IDENTIFIED

**Location:** `leaderboardService.js` lines 152-164 + `processLeaderboard()` function

### The Problem Chain:

1. **fetchUserStats()** (line 130-187) fetches LeetCode API data
2. Line 153: `const rawSubmissions = data.recentSubmissions || data.submission || [];`
3. Lines 154-164: Maps submissions but **LeetCode API doesn't include difficulty field**:

```javascript
const recentSubmissions = rawSubmissions.map((s) => {
  let difficulty = s.difficulty;  // ❌ THIS IS UNDEFINED
  if (!difficulty && s.titleSlug) difficulty = "Unknown";
  
  return {
    timestamp: parseInt(s.timestamp),
    difficulty: difficulty,  // ❌ Stored as "Unknown"
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  };
});
```

4. **processLeaderboard()** (line 911-929) is called with `timePeriod` param but **NEVER USES IT**:

```javascript
export function processLeaderboard(members, timePeriod, mode = "overall") {
  let processed = [...members];
  
  if (mode === "overall") {
    processed.sort((a, b) => (b.totalPoints || 0) - (a.totalPoints || 0));
  } else {
    processed.sort((a, b) => (b.contestPoints || 0) - (a.contestPoints || 0));
  }
  
  // ❌ timePeriod PARAMETER IS COMPLETELY IGNORED
  // No filtering by date
  // No recalculation of easy/medium/hard counts
  
  return processed.map((member, index) => ({
    ...member,
    rank: index + 1,
  }));
}
```

5. **EnhancedLeaderboard component** (not uploaded but referenced) likely:
   - Receives members with overall totals (easySolved=80, mediumSolved=60, hardSolved=10)
   - Tries to filter `recentSubmissions` array by date
   - Counts how many have `difficulty === "Easy"/"Medium"/"Hard"`
   - Since ALL have `difficulty === "Unknown"`, counts default to Easy

---

## THE FIX

### Strategy: Enrich submissions with difficulty metadata

**Option A: Add Problem Metadata Lookup (Recommended)**

Create `/services/problemMetadataService.js`:

```javascript
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';

const cache = new Map();

export async function getProblemDifficulty(titleSlug) {
  // Memory cache
  if (cache.has(titleSlug)) return cache.get(titleSlug);
  
  // Firestore cache
  const docRef = doc(db, 'problemMetadata', titleSlug);
  const docSnap = await getDoc(docRef);
  
  if (docSnap.exists()) {
    const difficulty = docSnap.data().difficulty;
    cache.set(titleSlug, difficulty);
    return difficulty;
  }
  
  // Fetch from LeetCode GraphQL
  try {
    const res = await fetch('https://leetcode.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `query($slug:String!){question(titleSlug:$slug){difficulty}}`,
        variables: { slug: titleSlug }
      })
    });
    const data = await res.json();
    const difficulty = data.data.question.difficulty;
    
    // Cache in Firestore
    await setDoc(docRef, { difficulty, updatedAt: new Date() });
    cache.set(titleSlug, difficulty);
    return difficulty;
  } catch (e) {
    return 'Medium'; // Safe fallback
  }
}

export async function enrichSubmissions(submissions) {
  return Promise.all(submissions.map(async (sub) => ({
    ...sub,
    difficulty: await getProblemDifficulty(sub.titleSlug)
  })));
}
```

**Modify `leaderboardService.js` line 152-164:**

```javascript
import { enrichSubmissions } from './problemMetadataService';

// Inside fetchUserStats():
const rawSubmissions = data.recentSubmissions || data.submission || [];

// ✅ FIX: Enrich with difficulty
const recentSubmissions = await enrichSubmissions(
  rawSubmissions.map((s) => ({
    timestamp: parseInt(s.timestamp),
    status: s.statusDisplay || s.status,
    titleSlug: s.titleSlug,
  }))
);
```

---

### Option B: Fix processLeaderboard() to Filter by Time

**Current (broken):**
```javascript
export function processLeaderboard(members, timePeriod, mode = "overall") {
  // timePeriod ignored ❌
  return members.map((m, i) => ({ ...m, rank: i + 1 }));
}
```

**Fixed:**
```javascript
export function processLeaderboard(members, timePeriod, mode = "overall") {
  let processed = [...members];
  
  // ✅ Apply time-based filtering
  if (timePeriod !== 'all') {
    const cutoffDate = getCutoffDate(timePeriod);
    
    processed = processed.map(member => {
      // Filter submissions by date
      const filteredSubs = (member.recentSubmissions || [])
        .filter(s => s.timestamp > cutoffDate);
      
      // Recalculate counts from filtered submissions
      const easy = filteredSubs.filter(s => s.difficulty === 'Easy').length;
      const medium = filteredSubs.filter(s => s.difficulty === 'Medium').length;
      const hard = filteredSubs.filter(s => s.difficulty === 'Hard').length;
      
      const totalPoints = easy * POINTS.EASY + 
                         medium * POINTS.MEDIUM + 
                         hard * POINTS.HARD;
      
      return {
        ...member,
        easySolved: easy,
        mediumSolved: medium,
        hardSolved: hard,
        totalSolved: easy + medium + hard,
        totalPoints
      };
    });
  }
  
  // Sort and rank
  processed.sort((a, b) => 
    mode === 'overall' 
      ? (b.totalPoints || 0) - (a.totalPoints || 0)
      : (b.contestPoints || 0) - (a.contestPoints || 0)
  );
  
  return processed.map((m, i) => ({ ...m, rank: i + 1 }));
}

function getCutoffDate(timePeriod) {
  const now = Date.now();
  if (timePeriod === 'week') return now - 7 * 24 * 60 * 60 * 1000;
  if (timePeriod === 'month') return now - 30 * 24 * 60 * 60 * 1000;
  return 0;
}
```

---

## RECOMMENDED APPROACH: Combine Both

1. **Phase 1 (Immediate):** Add problemMetadataService to enrich submissions
2. **Phase 2 (Next):** Fix processLeaderboard() to actually use timePeriod
3. **Phase 3 (Polish):** Add caching layer to avoid repeated metadata lookups

---

## VERIFICATION STEPS

After implementing fix:

1. Check console logs for difficulty enrichment: `console.log(recentSubmissions[0].difficulty)`
2. Inspect Firestore: Verify `problemMetadata` collection is being populated
3. Test monthly view: User with 50 problems should show correct easy/medium/hard breakdown
4. Test weekly view: User with no recent submissions should show 0/0/0

---

## COST IMPACT

- Firestore reads: +1 per unique problem slug (cached forever)
- LeetCode GraphQL calls: Only for NEW problem slugs (one-time)
- Typical group of 50 users × 500 submissions = ~500-1000 unique problems
- After initial population: Near-zero additional cost (pure cache hits)

---

## EDGE CASES TO HANDLE

1. **Deleted problems:** LeetCode GraphQL might return null → default to 'Medium'
2. **Malformed slugs:** Handle fetch errors gracefully
3. **Private/premium problems:** Might not be in public API → mark as 'Unknown'
4. **Time zone issues:** Use UTC timestamps consistently in filtering
